import xml.etree.ElementTree as ET
import sys

def main ():
	root = ET.parse (sys.argv [1]).getroot ()
	f = open ('outfile', 'w')

	for nei in root:
		for x in nei:
			if x.tag == 'address':
				f.write (x.attrib ['addr'] + '\n')
	f.close ()

if __name__ == '__main__':
	main ()
	
