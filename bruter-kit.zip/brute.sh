hydra -C lp -M outfile ssh -o goods.lst -vv

