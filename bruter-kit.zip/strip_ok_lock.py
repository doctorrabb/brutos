import sys

al = list ()

fw = open (sys.argv [2], 'w')
with open (sys.argv [1], 'r') as fl:
	for i in fl.readlines ():
		ll = i.strip ('\r\n').split ('   ')[0].split (':') [1].strip ()
		
		if not ll in al and not 'Hydra' in i:
			fw.write (ll + '\t' + i.strip ('\r\n').split ('   ')[1] + ' ' +i.strip ('\r\n').split ('   ')[2] + '\n')
			al.append (ll)
fl.close ()
fw.close ()
