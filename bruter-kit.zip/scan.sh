sudo masscan -p22 -iL diap.txt -oX test.xml -vv
